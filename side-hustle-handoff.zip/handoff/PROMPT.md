Paste this to Claude Code in the holeshot repo, with the `handoff/` folder in the repo root:

---

I want to bring my other game, Side Hustle City, into this repo and join it to Holeshot. Everything you need is in
`handoff/`. Start with `handoff/HANDOFF.md` and read all of it, then open
`handoff/reference/prototype-combined.html` to see the working prototype.

Before you write any code:

1. Tell me, briefly, how you plan to fit it into this repo.
2. Ask me the questions under "What no longer lines up" in HANDOFF.md. Give me your pick for each so I can just say yes or no.

Then build it on a new branch. Don't change how Race, Tour, Drag, Items or Crates behave on their own. When you're
done, run the build, the sim and the tests, and tell me what you checked and what you couldn't.

Don't commit the `handoff/` folder to main.
