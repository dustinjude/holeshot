// Drives the Nov 26 prototype in headless Chrome (puppeteer-core). Reference for the flows to cover with Playwright in the repo.
// npm i puppeteer-core three@0.128.0 && CHROME=/path/to/chrome node e2e-prototype.cjs
const pup=require('puppeteer-core'),fs=require('fs');
const USE3D=process.argv[2]==='3d';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  const br=await pup.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--hide-scrollbars',USE3D?'--enable-unsafe-swiftshader':'--disable-gpu','--use-angle=swiftshader']});
  const pg=await br.newPage();
  await pg.setViewport({width:390,height:780,deviceScaleFactor:1,hasTouch:true,isMobile:true});
  const errs=[];pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));pg.on('console',m=>{if(m.type()==='error'&&!/net::|Failed to load resource/.test(m.text()))errs.push('CONSOLE '+m.text())});
  await pg.setRequestInterception(true);
  pg.on('request',rq=>{const u=rq.url();
    if(u.includes('three.min.js'))return USE3D?rq.respond({status:200,contentType:'application/javascript',body:fs.readFileSync(require.resolve('three/build/three.min.js'))}):rq.abort();
    if(u.startsWith('http'))return rq.abort();rq.continue()});
  // run the race loop faster than real time: each frame advances a tenth of a second
  await pg.evaluateOnNewDocument(()=>{let t=0;window.requestAnimationFrame=f=>setTimeout(()=>{t+=100;f(t)},4)});
  await pg.goto('file://'+require('path').join(__dirname,'..','reference','prototype-combined.html'));await sleep(600);
  const C=(fn,...a)=>pg.evaluate(fn,...a);
  const city=()=>C(()=>{const h=document.getElementById('city'),r=h.shadowRoot;return {hidden:h.hidden,on:window.CITYON,clock:r.getElementById('clock').textContent,cash:r.getElementById('cash').textContent,modal:r.getElementById('modal').classList.contains('show')?r.querySelector('#sheet h3').textContent+': '+r.querySelector('#sheet .body').textContent.slice(0,200):null,acts:[...r.querySelectorAll('[data-a]')].map(b=>b.textContent+(b.disabled?' (x)':''))}});
  const cclick=sel=>C(sel=>{const r=document.getElementById('city').shadowRoot;const b=typeof sel==='string'&&sel.startsWith('text:')?[...r.querySelectorAll('button')].find(x=>x.textContent.includes(sel.slice(5))&&!x.disabled):r.querySelector(sel);if(!b)return false;b.dispatchEvent(new MouseEvent('click',{bubbles:true}));return true},sel);
  const hs=()=>C(()=>({start:!document.getElementById('start').hidden,result:!document.getElementById('result').hidden,pause:!document.getElementById('pause').hidden,go:!document.getElementById('go').hidden,goTxt:document.getElementById('go').textContent,setup:document.getElementById('setup').textContent,eyebrow:document.querySelector('#start .eyebrow').textContent,place:document.getElementById('place').textContent,sum:document.getElementById('sum').textContent,again:document.getElementById('again').textContent,g3:!document.getElementById('gl').hidden,info:HS.info()}));
  const hclick=id=>C(id=>{const b=document.getElementById(id);if(!b||b.disabled)return false;b.click();return true},id);
  console.log('BOOT',JSON.stringify(await city()),'3D:',(await hs()).g3);
  await pg.screenshot({path:'s_city.png'});
  await cclick('text:Let\'s go');
  // touch scroll of the city overlay
  const before=await C(()=>document.getElementById('city').scrollTop);
  await pg.touchscreen.touchStart(200,600);for(let y=600;y>200;y-=40){await pg.touchscreen.touchMove(200,y);await sleep(16)}await pg.touchscreen.touchEnd();await sleep(300);
  console.log('TOUCH SCROLL',before,'→',await C(()=>document.getElementById('city').scrollTop));
  await C(()=>{document.getElementById('city').scrollTop=0});
  // garage visit
  await cclick('[data-go="garage"]');let c=await city();if(c.modal){console.log('street modal',c.modal.slice(0,40));await C(()=>{const r=document.getElementById('city').shadowRoot;[...r.querySelectorAll('[data-ch]')].pop().click()})}
  console.log('AT GARAGE',JSON.stringify(await city()));
  console.log('work click',await cclick('text:Work on your ski'));await sleep(300);
  console.log('GARAGE VIEW',JSON.stringify(await hs()),'cityHidden',(await city()).hidden);
  await pg.screenshot({path:'s_garage.png'});
  console.log('buy disabled states',await C(()=>[...document.querySelectorAll('#garage .gbtn')].map(b=>b.textContent+(b.disabled?'(x)':'')).join(' | ')));
  await hclick('toCity');await sleep(200);
  console.log('BACK',JSON.stringify(await city()));
  // open race
  await cclick('[data-go="lake"]');c=await city();if(c.modal){await C(()=>{const r=document.getElementById('city').shadowRoot;[...r.querySelectorAll('[data-ch]')].pop().click()})}
  console.log('AT LAKE',JSON.stringify(await city()));
  await cclick('text:Run the open race');console.log('modal',(await city()).modal);
  await cclick('text:No side bet');await sleep(300);
  console.log('PITS',JSON.stringify(await hs()));
  await pg.screenshot({path:'s_pits.png'});
  await hclick('go');
  let t0=Date.now(),shot=false;
  while(Date.now()-t0<240000){const h=await hs();if(h.result)break;if(!shot&&Date.now()-t0>9000){shot=true;await pg.screenshot({path:'s_race.png'});console.log('mid-race hud',await C(()=>document.getElementById('hud').textContent.replace(/\s+/g,' ')))}await sleep(500)}
  console.log('RACE TOOK',((Date.now()-t0)/1000).toFixed(0)+'s','RESULT',JSON.stringify(await hs()));
  await pg.screenshot({path:'s_result.png'});
  await hclick('again');await sleep(300);
  console.log('AFTER RACE',JSON.stringify(await city()));
  await pg.screenshot({path:'s_after.png'});
  await cclick('text:OK');
  console.log('log',await C(()=>[...document.getElementById('city').shadowRoot.querySelectorAll('#log p')].slice(0,6).map(p=>p.textContent).join(' || ')));
  // jump to race day and retire from a tour moto
  await C(()=>{const s=JSON.parse(localStorage.getItem('shc'));s.day=5;s.h=10;s.en=90;s.at='lake';localStorage.setItem('shc',JSON.stringify(s))});
  await pg.reload();await sleep(600);
  console.log('RACE DAY',JSON.stringify(await city()));
  await cclick('text:Race moto');await sleep(300);console.log('TOUR PITS',JSON.stringify(await hs()));
  await hclick('go');await sleep(1500);await hclick('pauseBtn');await sleep(200);console.log('paused',(await hs()).pause,await C(()=>[...document.querySelectorAll('#pause button')].filter(b=>!b.hidden).map(b=>b.textContent).join(' | ')));
  await hclick('toSetup');await sleep(300);
  console.log('AFTER RETIRE',JSON.stringify(await city()),'info',JSON.stringify((await hs()).info));
  console.log('ERRORS',JSON.stringify(errs));
  await br.close();
})().catch(e=>{console.error('TEST FAIL',e);process.exit(1)});
