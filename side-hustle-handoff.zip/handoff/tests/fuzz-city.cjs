// Simulated players for the city alone (the race is a stub that returns a result at once).
// npm i jsdom && node fuzz-city.cjs   Expect: errors [] on every line, no BADTEXT, no STUCK.
const {JSDOM}=require('jsdom');const fs=require('fs');
const html=fs.readFileSync(require('path').join(__dirname,'city-stub.html'),'utf8');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function run(name,steps,smart){
  const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://x.test/',pretendToBeVisual:true});
  const w=dom.window,errs=[];w.addEventListener('error',e=>errs.push(e.message+' @'+e.lineno));
  await sleep(20);
  const d=w.document.getElementById('city').shadowRoot;
  const click=el=>el&&el.dispatchEvent(new w.MouseEvent('click',{bubbles:true}));
  const seen={};let stuck=0,bad=0;
  for(let i=0;i<steps;i++){
    const txt=d.textContent;
    if(/NaN|undefined|\[object/.test(txt)&&!bad){bad=1;const m=txt.match(/.{70}(NaN|undefined|\[object).{40}/);errs.push('BADTEXT: '+(m&&m[0]))}
    if(d.getElementById('modal').classList.contains('show')){
      const title=d.querySelector('#sheet h3').textContent;seen[title]=(seen[title]||0)+1;
      let b=[...d.querySelectorAll('[data-ch]')].filter(b=>!b.disabled);
      const nb=b.filter(x=>!/new life/i.test(x.textContent));if(nb.length)b=nb;
      if(smart){const y=b.filter(x=>/I'll be there|Bring it by|Send it|Pay it off|Do it|in your corner|Keep living|just race|Bet Marcus|Pink/.test(x.textContent));if(y.length&&Math.random()<.8)b=y}
      if(!b.length){stuck++;await sleep(20);if(stuck>60){errs.push('STUCK modal: '+title);break}continue}
      stuck=0;click(b[Math.floor(Math.random()*b.length)]);await sleep(0);continue}
    const x=Math.random();
    if(x<.03){click(d.getElementById('phone'));continue}
    let acts=[...d.querySelectorAll('[data-a]')].filter(b=>!b.disabled);
    if(smart){const good=acts.filter(b=>/shift|Sleep|Cook|Eat|Talk|Sit|Catch|Kick|Shoot|Hit the bags|Ask|Take|wants|needs|Fix the|Pull the|Race moto|open race|Work on your ski|Work your/.test(b.textContent));if(good.length&&Math.random()<.85)acts=good}
    const race=acts.find(b=>/Race moto/.test(b.textContent));
    if(race&&smart)click(race);
    else if(acts.length&&Math.random()<.7)click(acts[Math.floor(Math.random()*acts.length)]);
    else{const g=d.querySelectorAll('[data-go]');click(g[Math.floor(Math.random()*g.length)])}
    await sleep(0);
  }
  const S=JSON.parse(w.localStorage.getItem('shc'));
  console.log('#',name,'errors',JSON.stringify(errs),'|',d.getElementById('clock').textContent,d.getElementById('cash').textContent,'races',w.STUB.races,'q',JSON.stringify(S.q),'tourPos',S.tourPos,'season0',S.season0,'over',S.over);
  console.log('  you:',d.getElementById('you').textContent.slice(0,260));
  console.log('  modals:',Object.entries(seen).map(([k,v])=>k+'×'+v).join(', '));
  console.log('  log:',[...d.querySelectorAll('#log p')].slice(0,5).map(p=>p.textContent.slice(0,110)).join(' || '));
  w.close();
}
(async()=>{await run('random',1500,false);await run('smart',3000,true);await run('smart2',3000,true);})();
