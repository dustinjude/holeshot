// Drives the Nov 26 prototype in headless Chrome (puppeteer-core). Reference for the flows to cover with Playwright in the repo.
// npm i puppeteer-core three@0.128.0 && CHROME=/path/to/chrome node e2e2-prototype.cjs
const pup=require('puppeteer-core'),fs=require('fs');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
  const br=await pup.launch({executablePath:process.env.CHROME||'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--hide-scrollbars','--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-gpu-blocklist']});
  const pg=await br.newPage();
  await pg.setViewport({width:390,height:780,deviceScaleFactor:1,hasTouch:true,isMobile:true});
  const errs=[];pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));pg.on('console',m=>{if(m.type()==='error'&&!/net::|Failed to load resource/.test(m.text()))errs.push('CONSOLE '+m.text())});
  await pg.setRequestInterception(true);
  pg.on('request',rq=>{const u=rq.url();if(u.includes('three.min.js'))return rq.respond({status:200,contentType:'application/javascript',body:fs.readFileSync(require.resolve('three/build/three.min.js'))});if(u.startsWith('http'))return rq.abort();rq.continue()});
  await pg.evaluateOnNewDocument(()=>{let t=0;window.requestAnimationFrame=f=>setTimeout(()=>{t+=100;f(t)},4)});
  await pg.goto('file://'+require('path').join(__dirname,'..','reference','prototype-combined.html'));await sleep(800);
  const C=(fn,...a)=>pg.evaluate(fn,...a);
  const cclick=sel=>C(sel=>{const r=document.getElementById('city').shadowRoot;const b=[...r.querySelectorAll('button')].find(x=>x.textContent.includes(sel)&&!x.disabled);if(!b)return false;b.click();return true},sel);
  const hclick=id=>C(id=>{const b=document.getElementById(id);if(!b||b.disabled||b.hidden)return false;b.click();return true},id);
  const st=()=>C(()=>{const r=document.getElementById('city').shadowRoot;return {cityHidden:document.getElementById('city').hidden,clock:r.getElementById('clock').textContent,cash:r.getElementById('cash').textContent,modal:r.getElementById('modal').classList.contains('show')?r.querySelector('#sheet h3').textContent+': '+r.querySelector('#sheet .body').textContent:null,result:!document.getElementById('result').hidden,place:document.getElementById('place').textContent,again:document.getElementById('again').textContent,sum:document.getElementById('sum').textContent,g3:!document.getElementById('gl').hidden,info:HS.info(),you:r.getElementById('you').textContent}});
  await cclick("Let's go");
  console.log('3D on:',(await st()).g3);
  // moto 6 on day 30 with a built ski, dating Nia, friends with Tommy: checks the finale path
  await C(()=>{const s=JSON.parse(localStorage.getItem('shc'));Object.assign(s,{day:30,h:10,en:95,at:'lake',cash:5000});s.q.rosa=1;Object.assign(s.pp.nia,{met:1,rom:2,b:60,t:70,seen:29});Object.assign(s.pp.tommy,{met:1,b:70,t:80,seen:29});Object.assign(s.pp.marcus,{met:1,b:30,t:60,seen:29});localStorage.setItem('shc',JSON.stringify(s));
    localStorage.setItem('holeshot.tour10',JSON.stringify({round:5,pts:[60,80,50,40,70,30,20,10,5,45],r:0,c:0}));
    localStorage.setItem('holeshot.garage1',JSON.stringify({cls:0,crafts:{0:{p:[1,1,1,1,1,1,1,1],s:[0,0,0],w:[50,50,50]}}}))});
  await pg.reload();await sleep(800);
  let s=await st();console.log('FINALE DAY',s.clock,s.cash,JSON.stringify(s.info),'|',s.you);
  console.log('click moto',await cclick('Race moto'));await sleep(400);
  console.log('wear after Tommy:',(await st()).info.wear,'setup:',await C(()=>document.getElementById('setup').textContent+' | go: '+document.getElementById('go').textContent));
  await pg.screenshot({path:'s3_pits.png'});
  await hclick('go');let t0=Date.now(),shot=0;
  while(Date.now()-t0<300000){s=await st();if(s.result)break;if(!shot&&Date.now()-t0>12000){shot=1;await pg.screenshot({path:'s3_race.png'})}await sleep(500)}
  console.log('RACE',((Date.now()-t0)/1000).toFixed(0)+'s',s.place,'|',s.sum,'| btn:',s.again);
  await hclick('again');await sleep(300);s=await st();console.log('STANDINGS',s.place,'|',s.sum,'| btn:',s.again);
  await pg.screenshot({path:'s3_stand.png'});
  await hclick('again');await sleep(300);s=await st();console.log('CITY',s.cityHidden,s.clock,s.cash,'\n  modal:',s.modal,'\n  info',JSON.stringify(s.info),'\n  you:',s.you);
  await cclick('OK');
  // sleep into day 31: finale
  await C(()=>{const r=document.getElementById('city').shadowRoot;r.querySelector('[data-go="home"]').dispatchEvent(new MouseEvent('click',{bubbles:true}))});
  for(let i=0;i<4;i++){s=await st();if(s.modal){console.log('  modal:',s.modal.slice(0,420));if(/Champion|Legit|Clean|legend|liked|hustling|Kingpin/.test(s.modal))break;await C(()=>{const r=document.getElementById('city').shadowRoot;r.querySelector('[data-ch]').click()})}else await cclick('Sleep')}
  await cclick('Keep living');s=await st();console.log('AFTER FINALE',s.clock,'|',s.you.slice(0,200),'| log:',await C(()=>[...document.getElementById('city').shadowRoot.querySelectorAll('#log p')].slice(0,4).map(p=>p.textContent).join(' || ')));
  console.log('ERRORS',JSON.stringify(errs));await br.close();
})().catch(e=>{console.error('TEST FAIL',e);process.exit(1)});
