// The bridge as it was added to the END of the Nov 26 single-file Holeshot, inside its IIFE (after requestAnimationFrame(frame)).
// It uses that version's names and its 6-moto tour. Port the intent, not the text. HX is declared next to `gar` (see build.py).
// ---------- the city ----------
// Side Hustle City sits over this page. It opens the pits for a tour moto, an open race or a garage visit, and gets the result back.
function hsExit(){
  mode='idle'; paused=false; resAt=0; el.result.hidden=true; el.pause.hidden=true; el.start.hidden=true; setLive(false); audioFrame();
  window.CITYON=true; if(HX.exit) HX.exit();
}
// a moto the rider was not at: the rest of the field shares the points
function hsSkip(){
  const o=RACERS.map((r,i)=>i).filter(i=>i!==tour.r).sort((a,b)=>hash(a,tour.round,5)-hash(b,tour.round,5));
  o.forEach((ri,i)=>{tour.pts[ri]+=PTS[i];}); tour.round++; saveTour();
}
function hsRetire(){
  if(mode!=='race'&&mode!=='count') return;
  const inTour=gmode==='tour'; if(inTour) hsSkip();
  if(HX.done) HX.done({p:RACERS.length,prize:0,tour:inTour,site:site.name,mpos:1,dnf:1,round:tour.round,tpos:tourOrder().indexOf(tour.r)+1});
  hsExit();
}
window.CITYON=true; el.start.hidden=true;
el.modeS.parentNode.hidden=true; el.restart.hidden=true;
el.toSetup.removeEventListener('click',backToSetup); el.toSetup.textContent='Retire: counts as a DNF'; el.toSetup.addEventListener('click',hsRetire);
{const b=document.createElement('button'); b.type='button'; b.className='alt'; b.id='toCity'; b.textContent='Back to the city'; b.addEventListener('click',hsExit); el.start.appendChild(b);}
window.HS={
  wallet(g,s){HX.wget=g; HX.wset=s;},
  open(c){
    HX.disc=c.disc||1; HX.svc=c.svc||1; HX.purse=c.purse||1; HX.top=c.top||1; HX.turn=c.turn||1; HX.done=c.done||null; HX.exit=c.exit||null;
    const shop=c.mode==='garage'; HX.shop=shop;
    gmode=c.mode==='tour'?'tour':'single';
    if(gmode==='tour'&&tour.round>=TOUR.length) tour=freshTour();
    if(tourLive()){sel.r=tour.r; sel.c=tour.c;}
    if(sel.r===9) sel.r=0;
    tab=shop?'g':tab==='g'?'c':tab;
    el.go.hidden=shop;
    el.start.querySelector('.eyebrow').textContent=shop?'Tommy\'s Garage · your ski':gmode==='tour'?'Tour moto · 10 riders':'Open race · 10 riders';
    el.result.hidden=true; el.pause.hidden=true; el.start.hidden=false; mode='idle'; paused=false; resAction=startCountdown;
    window.CITYON=false; stage(); refreshSetup(); resize();
  },
  info(){
    const live=tour.round<TOUR.length, ci=myCraft(), b=build(ci);
    return {round:tour.round,next:live?SITES[TOUR[tour.round][0]].name:'',pts:tour.pts[tour.r]||0,pos:tourOrder().indexOf(tour.r)+1,
      cls:CLASSES[gar.cls].name,craft:CRAFTS[ci].name,parts:b.p.reduce((a,c)=>a+c,0),wear:Math.round(Math.min(b.w[0],b.w[1],b.w[2]))};
  },
  skip:hsSkip,
  newTour(){const r=tour.r, c=tour.c; tour=freshTour(); tour.r=r; tour.c=c; saveTour();},
  // lose a pink slip race and every part comes off the ski
  strip(){const b=build(myCraft()); b.p=PARTS.map(()=>0); saveGar();},
  fresh(){const b=build(myCraft()); b.w=WEAR.map(()=>100); saveGar();},
  // a part Dex can get: the next level of something not yet maxed, at half price
  offer(){const b=build(myCraft()), c=PARTS.map((p,i)=>i).filter(i=>b.p[i]<3); if(!c.length) return null;
    const i=c[Math.floor(Math.random()*c.length)]; return {i,name:PARTS[i].name,level:b.p[i]+1,cost:Math.round(PARTS[i].cost[b.p[i]]*.5/10)*10};},
  grant(i){const b=build(myCraft()); if(b.p[i]<3){b.p[i]++; saveGar();}},
  resetAll(){tour=freshTour(); saveTour(); gar.cls=0; gar.crafts={}; saveGar(); autoPace=.5; store('o8.pace','0.500');}
};
