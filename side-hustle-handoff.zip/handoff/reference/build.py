import re, sys, os
HS_SRC, CITY_SRC, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
hs = open(HS_SRC, encoding='utf8').read()
city = open(CITY_SRC, encoding='utf8').read()

def rep(s, old, new, n=1, tag=''):
    c = s.count(old)
    assert c == n, 'expected %d of %r, found %d %s' % (n, old[:70], c, tag)
    return s.replace(old, new)
def line_rep(s, prefix, new):
    ls = s.split('\n'); hit = [i for i, l in enumerate(ls) if l.startswith(prefix)]
    assert len(hit) == 1, 'line %r found %d' % (prefix[:60], len(hit))
    if new is None: del ls[hit[0]]
    else: ls[hit[0]] = new
    return '\n'.join(ls)

# ------------------------------------------------------------------ Holeshot patches
hs = rep(hs, '<title>Holeshot Closed Course</title>', '<title>Side Hustle Holeshot</title>')
hs = rep(hs, '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Condensed',
         '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bungee&family=Archivo:wght@400;600;800&display=swap">\n<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Condensed')
hs = rep(hs, 'you start with a bare ski and $3,500, and every finish pays prize money.', 'your ski starts bare, and every finish pays prize money. It is the same money you live on in the city.')
hs = rep(hs, "{name:'Wildcard',launch:1.03,", "{name:'Marcus',launch:1.03,")
hs = rep(hs, "let riv='3', autoPace=.5, racePace=.5;", "let riv='auto', autoPace=.5, racePace=.5;")
hs = rep(hs, "let gar={cash:3500,cls:0,crafts:{}};",
 "// the city sets these: prices, purse, small rider edges, and the wallet that the city and the garage share\n"
 "const HX={disc:1,svc:1,purse:1,top:1,turn:1,shop:true,done:null,exit:null,wget:()=>0,wset:()=>{}};\n"
 "const pcost=(p,l)=>Math.round(p.cost[l]*HX.disc/10)*10;\n"
 "let gar={cls:0,crafts:{}}; Object.defineProperty(gar,'cash',{get(){return HX.wget();},set(v){HX.wset(v);}});")
hs = rep(hs, "if(g&&g.cash>=0&&g.cls>=0&&g.cls<CLASSES.length&&g.crafts&&typeof g.crafts==='object') gar=g;",
             "if(g&&g.cls>=0&&g.cls<CLASSES.length&&g.crafts&&typeof g.crafts==='object'){gar.cls=g.cls; gar.crafts=g.crafts;}")
hs = rep(hs, "return garageMod(b.p.map(l=>Math.min(l,cap)),b.s,b.w);}", "const m=garageMod(b.p.map(l=>Math.min(l,cap)),b.s,b.w); m.top*=HX.top; m.turn*=HX.turn; return m;}")
hs = rep(hs, "function serviceCost(k,b){return SERVICE[k]+(k===1?250*b.p[3]:0);}", "function serviceCost(k,b){return Math.round((SERVICE[k]+(k===1?250*b.p[3]:0))*HX.svc/10)*10;}")
hs = rep(hs, "box.appendChild(E('div','eyebrow','Parts'));",
             "box.appendChild(E('div','eyebrow',HX.shop?'Parts'+(HX.disc<1?' · '+Math.round((1-HX.disc)*100)+'% off, shop price':''):'Parts · bought and fitted at Tommy\\'s Garage'));")
hs = rep(hs, "money(p.cost[l])); bt.id='buy'+i; bt.disabled=l>=3||gar.cash<p.cost[l];", "money(pcost(p,l))); bt.id='buy'+i; bt.disabled=l>=3||!HX.shop||gar.cash<pcost(p,l);")
hs = rep(hs, "if(n<3&&gar.cash>=p.cost[n]){gar.cash-=p.cost[n]; b.p[i]=n+1;", "if(n<3&&HX.shop&&gar.cash>=pcost(p,n)){gar.cash-=pcost(p,n); b.p[i]=n+1;")
hs = rep(hs, "prize=Math.round(PURSE[p-1]*CLASSES[gar.cls].pay*(.3+.7*racePace)/10)*10;", "prize=Math.round(PURSE[p-1]*CLASSES[gar.cls].pay*(.3+.7*racePace)*HX.purse/10)*10;")
hs = rep(hs, "if(inTour){el.again.textContent='Tour standings'; resAction=showStandings; el.swap.hidden=tour.round>=TOUR.length;}\n  else{el.again.textContent='Race again'; resAction=startCountdown; el.swap.hidden=false;}",
             "if(inTour){el.again.textContent='Tour standings'; resAction=showStandings;}\n  else{el.again.textContent='Back to the city'; resAction=hsExit;}\n  el.swap.hidden=true;\n"
             "  if(HX.done) HX.done({p,prize,tour:inTour,site:site.name,mpos:rows.findIndex(r=>r.ri===9)+1,dnf:0,round:tour.round,tpos:tourOrder().indexOf(tour.r)+1});")
hs = rep(hs, "el.again.textContent='Back to setup'; resAction=backToSetup; el.swap.hidden=true;", "el.again.textContent='Back to the city'; resAction=hsExit; el.swap.hidden=true;")
hs = rep(hs, "el.again.textContent='Next moto'; resAction=startCountdown; el.swap.hidden=false;", "el.again.textContent='Back to the city'; resAction=hsExit; el.swap.hidden=true;")
hs = rep(hs, "el.sum.textContent='Next: moto '+(tour.round+1)+' at '+SITES[st[0]].name+(st[1]?', reverse course.':'.');", "el.sum.textContent='Next: moto '+(tour.round+1)+' at '+SITES[st[0]].name+', in five days.';")
hs = rep(hs, "el.quit.hidden=!live; el.quit.textContent='Abandon tour'; quitArm=false;", "el.quit.hidden=true; quitArm=false;")
hs = rep(hs, "locked=inTour&&tourLive();", "locked=tourLive();")
hs = rep(hs, "p.textContent='Racer and craft are locked until this tour ends.';", "p.textContent='Racer and craft are locked until this tour ends. Your parts stay on this ski.';")
hs = rep(hs, "b.setAttribute('aria-pressed',String(i===cur)); b.disabled=locked;", "b.setAttribute('aria-pressed',String(i===cur)); b.disabled=locked||(racer&&i===9);")
hs = rep(hs, "function frame(ts){\n", "function frame(ts){\n  if(window.CITYON){last=ts; requestAnimationFrame(frame); return;}          // nothing runs or draws while you are in the city\n")
hs = rep(hs, "function key(e,d){\n", "function key(e,d){\n  if(window.CITYON) return;\n")
hs = rep(hs, "if(mode==='idle'||mode==='done'){e.preventDefault(); if(mode==='done'&&resAction) resAction(); else startCountdown();}", "if(mode==='idle'&&el.go.hidden) return;\n    if(mode==='idle'||mode==='done'){e.preventDefault(); if(mode==='done'&&resAction) resAction(); else startCountdown();}")

BRIDGE = r"""
// ---------- the city ----------
// Side Hustle City sits over this page. It opens the pits for a tour moto, an open race or a garage visit, and gets the result back.
function hsExit(){
  mode='idle'; paused=false; resAt=0; el.result.hidden=true; el.pause.hidden=true; el.start.hidden=true; setLive(false); audioFrame();
  window.CITYON=true; if(HX.exit) HX.exit();
}
// a moto the rider was not at: the rest of the field shares the points
function hsSkip(){
  const o=RACERS.map((r,i)=>i).filter(i=>i!==tour.r).sort((a,b)=>hash(a,tour.round,5)-hash(b,tour.round,5));
  o.forEach((ri,i)=>{tour.pts[ri]+=PTS[i];}); tour.round++; saveTour();
}
function hsRetire(){
  if(mode!=='race'&&mode!=='count') return;
  const inTour=gmode==='tour'; if(inTour) hsSkip();
  if(HX.done) HX.done({p:RACERS.length,prize:0,tour:inTour,site:site.name,mpos:1,dnf:1,round:tour.round,tpos:tourOrder().indexOf(tour.r)+1});
  hsExit();
}
window.CITYON=true; el.start.hidden=true;
el.modeS.parentNode.hidden=true; el.restart.hidden=true;
el.toSetup.removeEventListener('click',backToSetup); el.toSetup.textContent='Retire: counts as a DNF'; el.toSetup.addEventListener('click',hsRetire);
{const b=document.createElement('button'); b.type='button'; b.className='alt'; b.id='toCity'; b.textContent='Back to the city'; b.addEventListener('click',hsExit); el.start.appendChild(b);}
window.HS={
  wallet(g,s){HX.wget=g; HX.wset=s;},
  open(c){
    HX.disc=c.disc||1; HX.svc=c.svc||1; HX.purse=c.purse||1; HX.top=c.top||1; HX.turn=c.turn||1; HX.done=c.done||null; HX.exit=c.exit||null;
    const shop=c.mode==='garage'; HX.shop=shop;
    gmode=c.mode==='tour'?'tour':'single';
    if(gmode==='tour'&&tour.round>=TOUR.length) tour=freshTour();
    if(tourLive()){sel.r=tour.r; sel.c=tour.c;}
    if(sel.r===9) sel.r=0;
    tab=shop?'g':tab==='g'?'c':tab;
    el.go.hidden=shop;
    el.start.querySelector('.eyebrow').textContent=shop?'Tommy\'s Garage · your ski':gmode==='tour'?'Tour moto · 10 riders':'Open race · 10 riders';
    el.result.hidden=true; el.pause.hidden=true; el.start.hidden=false; mode='idle'; paused=false; resAction=startCountdown;
    window.CITYON=false; stage(); refreshSetup(); resize();
  },
  info(){
    const live=tour.round<TOUR.length, ci=myCraft(), b=build(ci);
    return {round:tour.round,next:live?SITES[TOUR[tour.round][0]].name:'',pts:tour.pts[tour.r]||0,pos:tourOrder().indexOf(tour.r)+1,
      cls:CLASSES[gar.cls].name,craft:CRAFTS[ci].name,parts:b.p.reduce((a,c)=>a+c,0),wear:Math.round(Math.min(b.w[0],b.w[1],b.w[2]))};
  },
  skip:hsSkip,
  newTour(){const r=tour.r, c=tour.c; tour=freshTour(); tour.r=r; tour.c=c; saveTour();},
  // lose a pink slip race and every part comes off the ski
  strip(){const b=build(myCraft()); b.p=PARTS.map(()=>0); saveGar();},
  fresh(){const b=build(myCraft()); b.w=WEAR.map(()=>100); saveGar();},
  // a part Dex can get: the next level of something not yet maxed, at half price
  offer(){const b=build(myCraft()), c=PARTS.map((p,i)=>i).filter(i=>b.p[i]<3); if(!c.length) return null;
    const i=c[Math.floor(Math.random()*c.length)]; return {i,name:PARTS[i].name,level:b.p[i]+1,cost:Math.round(PARTS[i].cost[b.p[i]]*.5/10)*10};},
  grant(i){const b=build(myCraft()); if(b.p[i]<3){b.p[i]++; saveGar();}},
  resetAll(){tour=freshTour(); saveTour(); gar.cls=0; gar.crafts={}; saveGar(); autoPace=.5; store('o8.pace','0.500');}
};
"""
hs = rep(hs, "requestAnimationFrame(frame);\n})();\n</script>", "requestAnimationFrame(frame);\n" + BRIDGE + "})();\n</script>")

# ------------------------------------------------------------------ the city, from Side Hustle City
css = re.search(r'<style>(.*?)</style>', city, re.S).group(1)
js = re.findall(r'<script>(.*?)</script>', city, re.S)[-1]

css = rep(css, ':root{color-scheme:light dark;', ':host{color-scheme:light dark;')
css = rep(css, ':root[data-theme=light]{color-scheme:light}:root[data-theme=dark]{color-scheme:dark}', ':host([data-theme=light]){color-scheme:light}:host([data-theme=dark]){color-scheme:dark}')
css = rep(css, 'body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 Archivo,system-ui,sans-serif;overflow-x:clip}',
  ':host{display:block;position:fixed;inset:0;z-index:20;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;'
  'padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);background:var(--bg);color:var(--ink);'
  'font:16px/1.5 Archivo,system-ui,sans-serif;text-align:left;-webkit-user-select:none;user-select:none}\n:host([hidden]){display:none}')

MARKUP = """<div class="wrap">
  <h1>Side Hustle Holeshot</h1>
  <p class="tag">$200, a studio apartment, a bare ski and a six-moto tour. Thirty days to get fast, get paid, or get locked up. Mature: language, crime, drinking, fights.</p>
  <div class="main">
    <div>
      <div class="status"><b id="clock"></b><b class="cash" id="cash"></b><span class="stars" id="stars" aria-label="Wanted level"></span><span id="rent" style="font-size:14px"></span><button class="ph" id="phone"></button></div>
      <div class="meters" id="meters"></div>
      <div class="mapbox"><svg class="map" id="map" viewBox="0 0 400 300" role="group" aria-label="City map"></svg></div>
    </div>
    <div class="panel" id="here"></div>
  </div>
  <div class="lower">
    <div class="panel"><h2>People</h2><p class="key"><i class="dot"></i>Bond: how close you are. <i class="dot t"></i>Trust: whether they believe you. Tap a name for more.</p><div id="people"></div></div>
    <div class="panel"><h2>You</h2><div id="you"></div></div>
    <div class="panel"><h2>Street log</h2><div class="log" id="log"></div><div style="margin-top:12px"><button id="reset">Start a new life <small>wipes save</small></button></div></div>
  </div>
</div>
<div class="modal" id="modal"><div class="sheet" id="sheet"></div></div>"""

js = js.strip()
assert js.startswith('{') and js.endswith('}'); js = js[1:-1]

# plumbing: the city lives in a shadow root over the race
js = rep(js, '$=id=>document.getElementById(id)', '$=id=>root.getElementById(id)')
js = rep(js, 'document.addEventListener("click"', 'root.addEventListener("click"')
js = rep(js, 'document.addEventListener("toggle"', 'root.addEventListener("toggle"')
js = rep(js, 'document.addEventListener("keydown"', 'root.addEventListener("keydown"')
js = line_rep(js, '  if(t.closest("#shift"))return runRace.shift&&runRace.shift();', None)
js = rep(js, 'function reset(){S=fresh();', 'function reset(){S=fresh();HS.resetAll();')

# places
js = rep(js, 'strip:{n:"The Strip",x:335,y:262,c:"#d2366b",o:[22,3],d:"Half a mile of empty industrial road."}};',
             'lake:{n:"The Lake",x:335,y:262,c:"#0f8a9a",o:[6,20],d:"Launch ramp, pit tents, race gas in the air. The tour comes through every five days."}};')
js = rep(js, 'd:"Three bays, forty years of oil in the floor."', 'd:"Three bays and a test tank, forty years of two-stroke in the floor. Skis get built here."')
js = rep(js, 'strip:"marcus"', 'lake:"marcus"')
js = rep(js, 'S.at==="garage"&&S.gar?"Yours now. Tommy still shows up at eight out of habit."', 'S.at==="garage"&&S.gar?"Yours now. Tommy still shows up at eight out of habit. Parts are at cost."')

# people
js = rep(js, 'marcus:{n:"Marcus",role:"street racer"', 'marcus:{n:"Marcus",role:"rival rider"')
js = rep(js, 'Marcus is holding court on the hood of his coupe, crew laughing at everything.', 'Marcus is holding court on the tailgate of his truck, crew laughing at everything.')
js = rep(js, 'Marcus is checking tire pressures, earbuds in.', 'Marcus is checking his wear ring with a flashlight, earbuds in.')
js = rep(js, 'Marcus is sitting in his car alone with the engine off.', 'Marcus is sitting on his ski at the bottom of the ramp, engine off, not launching.')
js = rep(js, '"The coupe was his father\'s. He\'s rebuilt everything on it except the driver\'s seat."', '"He built his ski out of three wrecked ones. He can tell you which bolt came from which."')
js = rep(js, 'He races because for eleven seconds it feels like going somewhere.', 'He races because for three laps it feels like going somewhere.')
js = rep(js, 'treat:["Buy him a jug of race gas",60]', 'treat:["Buy him a jug of race gas",60]')
js = rep(js, '"He\'s worked on every cop car, cab and church van in this city since 1979."', '"He\'s rebuilt every pump and supercharger on this lake since 1979. He can hear a bad wear ring from the parking lot."')
js = rep(js, 'drive:"Driving"', 'drive:"Riding"')
js = rep(js, 'jukebox playing something your dad liked.', 'jukebox playing something older than you are.')

# state
js = rep(js, 'lastEv:0,niaWait:0,prom:0,free:0,fin:0,\n', 'lastEv:0,niaWait:0,prom:0,free:0,fin:0,openDay:0,season0:0,hot:0,race:null,tourPos:0,\n')
js = rep(js, '// people\n', 'const ord=p=>p+(p===1?"st":p===2?"nd":p===3?"rd":"th"),motoDay=n=>S.season0+5*(n+1);\n// people\n')

# the calendar: a moto every five days; miss the day and the field takes the points
js = rep(js, '  hot();if(S.over)return;\n  if(rentDay(S.day)){', '  hot();if(S.over)return;\n  motoCheck();\n  if(rentDay(S.day)){')

# asks and events that talked about cars
js = rep(js, 'text:"Head gasket let go. Tommy says you\'re decent. Help me pull the head tomorrow? I\'d owe you."', 'text:"Supercharger let go in practice. Tommy says you\'re decent. Help me pull it tomorrow? I\'d owe you."')
js = rep(js, 'you spent a day wrenching on Marcus\'s coupe', 'you spent a day wrenching on Marcus\'s ski')
js = rep(js, 'when:()=>S.car>0&&stage("marcus")>=2,text:"Out-of-town crew on the Strip tonight talking reckless. Line up with us.",need:"race",what:"Race with Marcus\'s crew tonight"',
             'when:()=>stage("marcus")>=2,text:"Out-of-town crew at the ramp today talking reckless. Line up with us in the open race.",need:"race",what:"Run a race alongside Marcus\'s crew"')
js = rep(js, "Somebody's boosting cars on my beat and you hear things.", "Somebody's boosting skis and trailers off the ramp and you hear things.")
js = rep(js, 'now everybody on the Strip knows who gave Kowalski the name', 'now everybody at the ramp knows who gave Kowalski the name')
js = rep(js, 'counting cars with no plates', 'counting skis with no hull numbers')
js = rep(js, '"Ram the gate (need a car)"', '"Ram the gate (need a truck)"')
js = rep(js, "you own a garage that never has the same car twice", "you own a garage that never has the same ski twice")
js = rep(js, '"Marcus is saving for a faster car. He has a long memory."', '"Marcus is building another ski. He has a long memory."')
js = rep(js, '"Marcus still drives your old car. He waves."', '"Marcus runs your old parts on his ski. He waves."')
js = rep(js, 'Marcus\'s crew is tired of losing to you. Watch your back.', 'Marcus\'s crew is tired of you beating him. Watch your back.')

# Tommy's Garage: the ski, not a car
js = line_rep(js, '    if(!S.car)add("Buy the old junker"',
  '    add("Work on your ski",ts<0&&!S.gar?"Tommy won\'t have you in his shop":"parts, setup, service · 1 hr",ts>=0||!!S.gar,()=>enterRace("garage"),1);\n'
  '    if(!S.car)add("Buy Tommy\'s old truck","$1,200",S.cash>=1200,()=>{S.cash-=1200;S.car=1;log("A square-body pickup with a hitch and one working speaker. No more walking.")});')
js = line_rep(js, '    if(S.car===1)add("Bolt on a turbo"', None)
js = line_rep(js, '    if(S.car&&!S.tune)add("ECU tune it yourself"', None)
js = rep(js, '"Clutch job and two brake jobs. "', '"A supercharger rebuild and two wear rings. "')
js = rep(js, '"Brake jobs and an alternator. Tommy pays "', '"Two impeller swaps and a seized jet pump. Tommy pays "')
js = rep(js, 'add("Pull the head on Marcus\'s coupe","4 hrs"', 'add("Pull the supercharger on Marcus\'s ski","4 hrs"')
js = rep(js, '"Run stolen cars out the back"', '"Run stolen skis out the back"')
js = rep(js, 'Cars come in at night and leave as parts.', 'Skis come in at night and leave as parts.')

# the lake replaces the Strip
js = line_rep(js, '  if(at==="strip"){const ms=stage("marcus");',
  '  if(at==="lake"){const I=HS.info(),rd=I.round<6&&S.day===motoDay(I.round);\n'
  '    if(rd)add("Race moto "+(I.round+1)+" of 6","at "+I.next+" · 4 hrs",S.en>=30,()=>enterRace("tour"),1);\n'
  '    else if(I.round<6)add("Next moto: day "+motoDay(I.round),"at "+I.next,false,()=>{});\n'
  '    add("Run the open race",S.openDay===S.day?"one a day":"$40 fuel · 4 hrs · small purse",S.openDay!==S.day&&S.en>=30&&S.cash>=40,openRace);')
js = line_rep(js, '    add("Line up against Marcus",ms<0?', None)

# Dex can get parts
js = rep(js, '  if(D.b>=20)ch.push(["Run a package for him ($400)",pickup]);\n',
  '  if(D.b>=20)ch.push(["Run a package for him ($400)",pickup]);\n'
  '  const hp=HS.offer();\n'
  '  if(hp)ch.push(["Hot "+hp.name.toLowerCase()+", level "+hp.level+" · "+$$(hp.cost),()=>{S.cash-=hp.cost;HS.grant(hp.i);S.hot++;bond("dex",3);log("Dex: \\"Fell off a trailer in Parker.\\" The "+hp.name.toLowerCase()+" is real and half price. Don\'t let tech inspection look too close.");crime(8)},S.cash<hp.cost]);\n')

# street racing out, jet ski racing in
a, b = js.index('function race(){'), js.index('function copRoll(m){')
RACE = r'''const pal=()=>stage("marcus")>=2;
function motoCheck(){
  let I=HS.info(),g=0;
  if(I.round>=6&&S.day>motoDay(5)){S.season0=motoDay(5);HS.newTour();I=HS.info();log("A new tour is posted at the ramp. First moto on day "+motoDay(0)+".")}
  while(I.round<6&&S.day>motoDay(I.round)&&g++<8){log("You missed moto "+(I.round+1)+" at "+I.next+". No points.");S.rep=cl(S.rep-2);HS.skip();I=HS.info();if(I.round>=6)S.tourPos=I.pos}
  if(I.round<6&&S.day===motoDay(I.round)){log("Race day. Moto "+(I.round+1)+" at "+I.next+". Be at the Lake before 8pm.");pq("raceday")}
}
function openRace(){
  const ms=stage("marcus"),ch=[["No side bet, just race",()=>enterRace("open")]];meet("marcus");
  if(ms>=0){
    for(const b of [100,300,1000])ch.push(["Bet Marcus "+$$(b)+" you beat him to the flag",()=>enterRace("open",{bet:b}),S.cash<b+40]);
    if(S.mwins>=2&&!S.q.marcus)ch.push(["Pink slips: his build against yours",()=>enterRace("open",{pinks:1})]);
  }
  ch.push(["Back out",0]);
  modal("Open race","Ten skis, three laps, a small purse and $40 in fuel. Marcus is on the line already. \""+(ms<0?"Stay on your side of the ramp.":ms>=2?"Loser buys breakfast. Want to make it interesting?":S.mwins>=2&&!S.q.marcus?"You think you're quick? Put your whole build on it.":S.salt?"You want another one? Fine.":"New face. Put your money where your pump is.")+"\"",ch);
}
// kind: tour, open or garage. The race page takes over until it hands a result back.
function enterRace(kind,o){
  if(kind==="tour"){
    if(pp("tommy").met&&stage("tommy")>=3){HS.fresh();log("Tommy went through your ski last night. Fresh plugs, fresh wear ring, no charge.")}
    if(S.hot&&r()<.25*S.hot){S.hot=0;S.cash=Math.max(0,S.cash-500);S.rep=cl(S.rep-5);log("Tech inspection finds a serial number that isn't yours. $500 fine, and everybody in the pits watched.");crime(8);if(S.over)return}
  }
  S.race=Object.assign({kind,day:S.day},o||{});save();
  HS.open({mode:kind,disc:S.gar?.75:pp("tommy").met&&stage("tommy")>=2?.85:1,svc:Math.max(.5,1-.1*lvl("wrench")),purse:kind==="tour"?1:.3,
    turn:1+.008*lvl("drive"),top:S.en<40?.98:1,done:raceDone,exit:cityBack});
  host.hidden=true;
}
function raceDone(res){
  const R=S.race||{kind:"open"},tour=R.kind==="tour",M=pp("marcus"),ahead=!res.dnf&&res.mpos>res.p,L=[];
  S.race=null;
  if(!tour){S.openDay=S.day;S.cash=Math.max(0,S.cash-40)}
  tick(4);if(S.over)return;
  S.en=cl(S.en-30);S.mood=cl(S.mood+(res.dnf?-10:res.p<=3?15:res.p>=8?-6:4));
  if(!res.dnf)S.rep=cl(S.rep+Math.round([8,5,3,2,1,0,0,0,0,0][res.p-1]*(tour?1:.5)));
  xp("drive",!res.dnf&&res.p<=3?3:2);
  L.push(res.dnf?"You retired from the race. No points, no money.":(tour?"Moto "+res.round+" at ":"Open race at ")+res.site+": "+ord(res.p)+" of 10. Prize "+$$(res.prize)+".");
  if(tour&&!res.dnf){
    if(S.q.rosa===1){S.cash+=100;L.push("Lucky's pays you $100 for the sticker on your hull.")}
    const N=pp("nia"),T=pp("tommy");
    if(N.rom===2||N.rom===3){bond("nia",res.p<=3?4:2);meet("nia");L.push(res.p<=3?"Nia was on the beach, loud enough to hear over ten engines.":"Nia was on the beach. \"You looked good out there. Mostly.\"")}
    if(T.met&&stage("tommy")>=2&&res.p<=3){bond("tommy",3);L.push("Tommy nods at the trophy like he built it. He sort of did.")}
  }
  if(tour){
    if(res.round>=6){S.tourPos=res.tpos;L.push("That was the last moto. You finish the tour "+ord(res.tpos)+"."+(res.tpos===1?" Champion.":""));if(res.tpos===1){S.rep=cl(S.rep+15);for(const k in P)if(pp(k).met)bond(k,3)}}
    else L.push("Tour standing: "+ord(res.tpos)+". Next moto is day "+motoDay(res.round)+".");
  }
  if(M.met&&!res.dnf){
    if(ahead){S.mwins++;if(pal())bond("marcus",1);else{S.salt++;bond("marcus",-2)}}else bond("marcus",2);
    if(R.bet){
      if(ahead){S.cash+=R.bet;rem("marcus","Lost "+$$(R.bet)+" to you on the water");L.push("You beat Marcus to the flag. He pays out "+$$(R.bet)+" without a word.")}
      else{S.cash=Math.max(0,S.cash-R.bet);rem("marcus","Took "+$$(R.bet)+" off you on the water");L.push("Marcus finished ahead of you. He counts your "+$$(R.bet)+" slowly, right in front of you.")}}
  }else if(R.bet){S.cash=Math.max(0,S.cash-R.bet);L.push("A DNF loses the bet. Marcus takes your "+$$(R.bet)+".")}
  for(const l of L)log(l);
  did("race");
  modal(res.dnf?"Did not finish":tour?"Moto "+res.round+" of 6":"Open race",L.join(" "),[["OK",0]]);
  if(R.pinks){
    if(ahead)modal("Pink slips","You beat him to the flag with his whole crew watching. Marcus kills his engine and holds out the lanyard. He built that ski out of three wrecked ones.",[
      ["Keep his ski",()=>{S.cash+=4000;S.q.marcus=2;scar("marcus",35,20);bond("marcus",-20);rem("marcus","You took the ski he built");gossip("marcus",-8,"you took Marcus's ski on a pink slip");log("You sell Marcus's ski to Sal by lunch. $4,000. Marcus watches the trailer leave.")}],
      ["Toss the lanyard back",()=>{S.q.marcus=3;bond("marcus",35);trust("marcus",20);S.rep=cl(S.rep+10);rem("marcus","You won his ski and gave it back");gossip("marcus",8,"you beat Marcus for his ski and handed it back");log("\"Keep it. I just wanted to know.\" Marcus stares at you. \"I owe you one.\" He means it.")}]]);
    else{HS.strip();S.q.marcus=4;bond("marcus",4);rem("marcus","Runs your parts now");log("Lost the pink slip race. Every part you bought leaves in Marcus's truck.");
      modal("Pink slips","Marcus beat you to the flag. His crew has your ski on a stand before you're out of your vest. Every part you bought leaves in his truck. Tommy lends you the bare hull back.",[["Damn",0]])}
  }
}
function cityBack(){
  window.CITYON=true;host.hidden=false;
  if(S.race){if(S.race.kind==="garage"){tick(1);meet("tommy");log("An hour on the stand at Tommy's with your ski.")}S.race=null}
  render();host.scrollTop=0;
}
'''
js = js[:a] + RACE + js[b:]
js = rep(js, '+(stage("marcus")>=2?.15:0)){S.rep=cl(S.rep+4);', '+(pal()?.15:0)){S.rep=cl(S.rep+4);')

# the card that says who you are
js = rep(js, '<b>${S.coupe?"Marcus\'s coupe":S.car===2?"Turbo hatchback":S.car?"Junker hatchback":"On foot"}${S.tune?", tuned":""}</b></div>`',
  '<b>${S.car?"Old pickup":"On foot"}</b></div>`\n'
  '   +`<div class="row"><span>Ski</span><b>${I.craft} · ${I.cls} · ${I.parts} part level${I.parts===1?"":"s"}${I.wear<60?" · needs service":""}</b></div>`\n'
  '   +`<div class="row"><span>Tour</span><b>${I.round>=6?"Finished "+ord(S.tourPos||I.pos):(I.round?ord(I.pos)+" on "+I.pts+" pts · ":"")+"moto "+(I.round+1)+" on day "+motoDay(I.round)}</b></div>`')
js = rep(js, '  let nr=S.day+1;while(!rentDay(nr))nr++;$("rent").textContent="Rent "',
             '  const I=HS.info(),rdToday=I.round<6&&S.day===motoDay(I.round);\n  let nr=S.day+1;while(!rentDay(nr))nr++;$("rent").textContent=(rdToday?"Race day · ":"")+"Rent "')
js = rep(js, '${all?"always open":(op?"open":"closed")+" · "+fmtH(l.o[0])+"–"+fmtH(l.o[1])}', '${k==="lake"&&rdToday&&op?"race day · until 8pm":all?"always open":(op?"open":"closed")+" · "+fmtH(l.o[0])+"–"+fmtH(l.o[1])}')

# endings
js = rep(js, 'function verdict(){return S.gar&&S.chop?', 'function verdict(){return S.tourPos===1?["Champion","Six motos, and your name is at the top of the sheet at Havasu. Whatever else you did to get here, nobody can say you didn\'t earn that part."]\n :S.gar&&S.chop?')
js = rep(js, '  S.loan?"You still owe Sal "+$$(S.loan.amt)+". He hasn\'t forgotten.":"",\n  fr?', '  S.loan?"You still owe Sal "+$$(S.loan.amt)+". He hasn\'t forgotten.":"",\n  S.tourPos>1?"You finished the tour "+ord(S.tourPos)+".":"",\n  fr?')

js = rep(js, 'const EV={\n ask:id=>showAsk(id),', 'const EV={\n ask:id=>showAsk(id),\n raceday(){const I=HS.info();if(I.round<6&&S.day===motoDay(I.round))modal("Race day","Moto "+(I.round+1)+" of 6 is today, at "+I.next+". Be at the Lake before 8pm with some energy left. Miss it and the rest of the field shares the points.",[["Got it",0]])},')
# first run
js = rep(js, 'modal("Day 1","New city, $200, rent due on day 8. Tap the map to get around.<ul>', 'modal("Day 1","New city, $200, a bare ski, rent due on day 8. Tap the map to get around.<ul><li>The tour races every five days, starting day 5. Be at the Lake on race day. Pick your rider and ski in the pits before the first moto. The ski gets built at Tommy\'s Garage, out of the same money you live on.</li>')
js = rep(js, 'const first=!S.log.length;', 'HS.wallet(()=>S.cash,v=>{S.cash=Math.max(0,Math.round(v));save()});\nif(S.race)S.race=null;\nconst first=!S.log.length;')
js = rep(js, 'log("Day 1. $200 and a studio apartment. Rent\'s due on day 8.")', 'log("Day 1. $200, a studio apartment and a bare ski. Rent\'s due on day 8. First moto is day 5.")', 2)

for bad in ['runRace', 'coupe', 'Strip', 'junker', 'hatchback', 'S.tune', '"strip"']:
    hits = [l[:120] for l in js.split('\n') if bad in l and 'coupe:0' not in l and 'tune:0' not in l]
    if hits: print('LEFTOVER', bad, hits[:3])

HEAD = '''(()=>{
// Side Hustle City. It lives in a shadow root laid over the race, so neither page's styles reach the other.
const host=document.getElementById("city"),root=host.attachShadow({mode:"open"});
root.appendChild(document.getElementById("cityT").content.cloneNode(true));
const HS=window.HS;
{const st=()=>{const t=document.documentElement.dataset.theme;if(t)host.dataset.theme=t;else delete host.dataset.theme};st();new MutationObserver(st).observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]})}
'''
CITY_BLOCK = '<div id="city"></div>\n<template id="cityT"><style>' + css + '</style>\n' + MARKUP + '\n</template>\n<script>\n' + HEAD + js + '\n})();\n</script>\n'
assert hs.rstrip().endswith('</body></html>')
full = hs.rstrip()[:-len('</body></html>')].rstrip() + '\n' + CITY_BLOCK + '</body></html>\n'
os.makedirs(OUT, exist_ok=True)
open(os.path.join(OUT, 'index.html'), 'w', encoding='utf8').write(full)

# a city-only page for simulated players: the race is replaced by a stub that hands back a result at once
STUB = '''<script>
(()=>{let round=0,pts=0,parts=0;window.STUB={races:0};
window.HS={wallet(){},resetAll(){round=0;pts=0;parts=0},newTour(){round=0;pts=0},skip(){round++},strip(){parts=0},fresh(){},
 offer(){return parts<24?{i:parts%8,name:"Exhaust",level:1,cost:350}:null},grant(){parts++},
 info(){return {round,next:"Test Lake",pts,pos:3,cls:"Stock",craft:"Sea-Doo 325",parts,wear:80}},
 open(c){if(c.mode==="garage")return setTimeout(c.exit,0);const dnf=Math.random()<.1,p=dnf?10:1+Math.floor(Math.random()*10),tour=c.mode==="tour";if(tour){round++;pts+=dnf?0:26-2*p}STUB.races++;
  c.done({p,prize:dnf?0:Math.round((2000-180*p)*c.purse),tour,site:"Test Lake",mpos:1+Math.floor(Math.random()*10),dnf:dnf?1:0,round,tpos:1+Math.floor(Math.random()*10)});setTimeout(c.exit,0)}};
})();
</script>
'''
open(os.path.join(OUT, 'citytest.html'), 'w', encoding='utf8').write('<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>\n' + STUB + CITY_BLOCK + '</body></html>')
print('ok', len(full), 'bytes;', full.count('\n'), 'lines')
